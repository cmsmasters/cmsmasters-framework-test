<?php
/**
 * Plugin Name: CMSMasters Framework
 * Plugin URI: http://cmsmasters.net/
 * Description: CMSMasters Framework uses for themes.
 * Author: CMSMasters
 * Version: 1.0.0
 * Author URI: http://cmsmasters.net/
 *
 * Text Domain: cmsmasters-framework
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'CMSMASTERS_FRAMEWORK_VERSION', '1.0.0' );

define( 'CMSMASTERS_FRAMEWORK__FILE__', __FILE__ );
define( 'CMSMASTERS_FRAMEWORK_PLUGIN_BASE', plugin_basename( CMSMASTERS_FRAMEWORK__FILE__ ) );
define( 'CMSMASTERS_FRAMEWORK_PATH', plugin_dir_path( CMSMASTERS_FRAMEWORK__FILE__ ) );
define( 'CMSMASTERS_FRAMEWORK_URL', plugins_url( '/', CMSMASTERS_FRAMEWORK__FILE__ ) );

define( 'CMSMASTERS_FRAMEWORK_CORE_PATH', CMSMASTERS_FRAMEWORK_PATH . 'core/' );

/**
 * CMSMasters Framework initial class.
 *
 * The plugin file that checks all the plugin requirements and
 * run main plugin class.
 *
 * @since 1.0.0
 */
final class Cmsmasters_Framework {

	/**
	 * Disable class cloning and throw an error on object clone.
	 *
	 * The whole idea of the singleton design pattern is that there is a single
	 * object. Therefore, we don't want the object to be cloned.
	 * That's why cloning instances of the class is forbidden.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, __( 'Something went wrong.', 'cmsmasters-framework' ), '1.0.0' );
	}

	/**
	 * Disable unserializing of the class.
	 *
	 * Unserializing instances of the class is forbidden.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, __( 'Something went wrong.', 'cmsmasters-framework' ), '1.0.0' );
	}

	/**
	 * Initial class constructor.
	 *
	 * Initializing file class.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_autoloader();

		add_action( 'init', array( $this, 'i18n' ) );
		add_action( 'after_setup_theme', array( $this, 'init' ) );
		add_action( 'admin_init', array( $this, 'check_theme_compatibility' ) );

		register_activation_hook( CMSMASTERS_FRAMEWORK__FILE__, array( $this, 'activation_check_theme_compatibility' ) );
	}

	/**
	 * Register autoloader.
	 *
	 * Autoloader loads all the plugin files.
	 *
	 * @since 1.0.0
	 */
	private function register_autoloader() {
		require_once CMSMASTERS_FRAMEWORK_CORE_PATH . 'autoloader.php';

		CmsmastersFramework\Autoloader::run();
	}

	/**
	 * Load plugin localization files.
	 *
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 */
	public function i18n() {
		load_plugin_textdomain( 'cmsmasters-framework', false, dirname( CMSMASTERS_FRAMEWORK_PLUGIN_BASE ) . '/languages/' );
	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after other plugins are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @return void Or require main Plugin class
	 */
	public function init() {
		/**
		 * The main handler class.
		 */
		require CMSMASTERS_FRAMEWORK_CORE_PATH . 'plugin.php';

		new CmsmastersFramework\Plugin();
	}

	/**
	 * Check if theme have needed constants.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function has_theme_constants() {
		if (
			defined( 'CMSMASTERS_FRAMEWORK_COMPATIBILITY' ) &&
			CMSMASTERS_FRAMEWORK_COMPATIBILITY &&
			defined( 'CMSMASTERS_THEME_NAME' ) &&
			defined( 'CMSMASTERS_OPTIONS_PREFIX' ) &&
			defined( 'CMSMASTERS_OPTIONS_NAME' ) &&
			defined( 'CMSMASTERS_THEME_IMPORT_TYPE' )
		) {
			return true;
		}

		return false;
	}

	/**
	 * Check theme compatibility on plugin activation.
	 *
	 * @since 1.0.0
	 */
	public function activation_check_theme_compatibility() {
		if ( $this->has_theme_constants() ) {
			return;
		}

		deactivate_plugins( CMSMASTERS_FRAMEWORK_PLUGIN_BASE );

		wp_die(
			esc_html__( "Your theme doesn't support CMSMasters Framework plugin. Please use appropriate CMSMasters theme.", 'cmsmasters-framework' ),
			esc_html__( "Error!", 'cmsmasters-framework' ),
			array(
				'back_link' => 	true,
			)
		);
	}

	/**
	 * Check theme compatibility.
	 *
	 * @since 1.0.0
	 */
	public function check_theme_compatibility() {
		if ( $this->has_theme_constants() ) {
			return;
		}

		deactivate_plugins( CMSMASTERS_FRAMEWORK_PLUGIN_BASE );

		add_action('admin_notices', function() {
			echo '<div class="notice notice-warning is-dismissible">
				<p><strong>' . esc_html__( "CMSMasters Framework plugin was deactivated, because your theme doesn't support it. Please use appropriate CMSMasters theme.", 'cmsmasters-framework') . '</strong></p>
			</div>';
		} );
	}

}

new Cmsmasters_Framework();
